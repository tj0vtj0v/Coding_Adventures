import numpy as np
from PIL import Image
import math
#enter here additional imports
x_range = 10
y_range = 4
x_guide_point_distance = .5
y_guide_point_distance = .5
coordinate_system_line_size = 5
x_res = 800
y_res = 800
x_offset = 0
y_offset = 0
line_width_factor = .025
grid_bool = False
backgroud_color = (0, 0, 0)
coordinate_system_color = (255, 128, 128)
coordinate_marker_color = (228, 228, 228)
graph_color = (255, 255, 255)
y_range = y_range*2
x_range = x_range*2
y_offset = y_offset*y_res
x_offset = x_offset*x_res
x_range = int(x_range*x_res)
y_range = int(y_range*y_res)
pixel_array = []
for original_y in range(y_range):
	print("Process: " + str(original_y) + "/" + str(y_range) + "_________" + str(int(100*original_y/y_range)), end="%\r")
	y = (((original_y - y_range/2) - y_offset)*(1/y_res))
	y_center = original_y - y_range/2 - y_offset
	x_pixel_storage = []
	for original_x in range(x_range):
		x = (((original_x - x_range/2) + x_offset)*(1/x_res))
		x_center = original_x - x_range/2 + x_offset
		if abs(-(math.sin((x+y)*(x+y)) ) - y) <= line_width_factor: x_pixel_storage.append(graph_color)
		elif (y%y_guide_point_distance)*y_res <= 2*coordinate_system_line_size and abs(x*x_res) <= coordinate_system_line_size: x_pixel_storage.append(coordinate_marker_color)
		elif (x%x_guide_point_distance)*x_res <= 2*coordinate_system_line_size and abs(y*y_res) <= coordinate_system_line_size: x_pixel_storage.append(coordinate_marker_color)
		elif abs(y_center) <= coordinate_system_line_size: x_pixel_storage.append(coordinate_system_color)
		elif abs(x_center) <= coordinate_system_line_size: x_pixel_storage.append(coordinate_system_color)
		elif (y%y_guide_point_distance)*y_res <= 2*coordinate_system_line_size and grid_bool: x_pixel_storage.append(coordinate_marker_color)
		elif (x%x_guide_point_distance)*x_res <= 2*coordinate_system_line_size and grid_bool: x_pixel_storage.append(coordinate_marker_color)
		else: x_pixel_storage.append(backgroud_color)
	pixel_array.append(x_pixel_storage)
array = np.array(pixel_array, dtype=np.uint8)
image = Image.fromarray(array)
image.show()
if "y" == input("do you whant to save the image? (y/n): "):
	name = input("please enter filename without file_format (.png, etc): ")
	image.save(name + ".png", "PNG")
